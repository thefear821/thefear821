package com.example.metanit;

public class ThirdActivity {

}
